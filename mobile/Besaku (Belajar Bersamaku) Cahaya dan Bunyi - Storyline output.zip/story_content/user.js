function ExecuteScript(strId)
{
  switch (strId)
  {
      case "67xsWafeYGx":
        Script1();
        break;
      case "5m6ePi1Wchg":
        Script2();
        break;
      case "6Bn1q5vmX0E":
        Script3();
        break;
      case "6Jj8dt8IV0l":
        Script4();
        break;
      case "5sKYfHoeRJc":
        Script5();
        break;
      case "6T9RutjksCs":
        Script6();
        break;
      case "6KyHxQsS8jo":
        Script7();
        break;
      case "6goFVOQ61La":
        Script8();
        break;
      case "5xLE0G26gXd":
        Script9();
        break;
      case "5pUEENZLPFe":
        Script10();
        break;
      case "6I0cE2BpS4S":
        Script11();
        break;
      case "6Q7a1ILHrNM":
        Script12();
        break;
      case "6eWx7UvtH53":
        Script13();
        break;
      case "6G8NKKXRACP":
        Script14();
        break;
      case "61bYDRGaKuY":
        Script15();
        break;
      case "5oE4dy8M27F":
        Script16();
        break;
      case "6FnXjXqPlyW":
        Script17();
        break;
      case "5Zr3r2ejLen":
        Script18();
        break;
      case "6Som8XznH7k":
        Script19();
        break;
      case "5kJYDof4RpO":
        Script20();
        break;
      case "6QxX7mynImf":
        Script21();
        break;
      case "5xMojNEe0gu":
        Script22();
        break;
      case "6Bko3rp3W6Y":
        Script23();
        break;
      case "5dHiyWvKmrp":
        Script24();
        break;
      case "5w8WFrg3M9L":
        Script25();
        break;
      case "5Xazrt6YWdC":
        Script26();
        break;
      case "6QqwNAQzDpp":
        Script27();
        break;
      case "6Y9JHynTL1Q":
        Script28();
        break;
      case "5sIK2nWNcc1":
        Script29();
        break;
      case "6fydm9Sx0YO":
        Script30();
        break;
      case "6AmfCq4CWTE":
        Script31();
        break;
      case "5wZSxowpaT8":
        Script32();
        break;
      case "6GpTrD5M0YX":
        Script33();
        break;
      case "6OAHJw8fMAf":
        Script34();
        break;
      case "6HRoqojpA1p":
        Script35();
        break;
      case "5h3EPEZat5k":
        Script36();
        break;
      case "6e9waUJPttg":
        Script37();
        break;
      case "6bt5XZWFkY6":
        Script38();
        break;
      case "5n2KXMD01KC":
        Script39();
        break;
      case "6AdtWHWiu0N":
        Script40();
        break;
      case "5WIQGEbRntG":
        Script41();
        break;
      case "6DohBsXFgIE":
        Script42();
        break;
      case "5cQrWCEG6Yo":
        Script43();
        break;
      case "6luj3522RDn":
        Script44();
        break;
      case "5YuYo30JaF6":
        Script45();
        break;
      case "6B41PZEAc2C":
        Script46();
        break;
      case "6mvkp5mfpWG":
        Script47();
        break;
      case "6lR6yfFVUgg":
        Script48();
        break;
      case "6jMUHeUOoaw":
        Script49();
        break;
      case "5jIiChmINqu":
        Script50();
        break;
      case "6e5jloLv9op":
        Script51();
        break;
      case "6DVTNbrOKQS":
        Script52();
        break;
      case "6Qxk2PK7p1X":
        Script53();
        break;
      case "65pYNpK4PmO":
        Script54();
        break;
      case "6KjnWfbFroN":
        Script55();
        break;
      case "5xqLeqTd2HO":
        Script56();
        break;
      case "5l73FfwdSqz":
        Script57();
        break;
      case "5oZJXQUwFpu":
        Script58();
        break;
      case "5VWWoRXih6l":
        Script59();
        break;
      case "5qvaypPH0RF":
        Script60();
        break;
      case "62mfqOi5Srv":
        Script61();
        break;
      case "6ZDf35PRDAl":
        Script62();
        break;
      case "5ul8GP8dsiK":
        Script63();
        break;
      case "67cQeSJbMLF":
        Script64();
        break;
      case "6IVgpBQ19bk":
        Script65();
        break;
      case "5jyS0pxjhBl":
        Script66();
        break;
      case "5dCzV1C8BzV":
        Script67();
        break;
      case "6WsBNsdUEzP":
        Script68();
        break;
      case "6jrVNPG6B0M":
        Script69();
        break;
      case "5dYvNKldenB":
        Script70();
        break;
      case "6TIKdiGy5Hu":
        Script71();
        break;
      case "5h77ZdqBSlM":
        Script72();
        break;
      case "5pCx6VzEk48":
        Script73();
        break;
      case "6ngYdIHxetz":
        Script74();
        break;
      case "5drosbl8j19":
        Script75();
        break;
      case "5weoiSCYpW6":
        Script76();
        break;
      case "5ZnJv9JpHCU":
        Script77();
        break;
      case "6JngvIqYcNa":
        Script78();
        break;
      case "6P3IBPH8cBO":
        Script79();
        break;
      case "5zy2V966QcV":
        Script80();
        break;
      case "6941UqMjX1w":
        Script81();
        break;
      case "5zXtUGU8JXr":
        Script82();
        break;
      case "6iqsC3ssvgB":
        Script83();
        break;
      case "5ntTh8jLRFY":
        Script84();
        break;
      case "5rVUsn9ZmYu":
        Script85();
        break;
      case "6CJgyvkQ1ig":
        Script86();
        break;
      case "5XO8ClIrQHA":
        Script87();
        break;
      case "5WAI5VesCHn":
        Script88();
        break;
      case "5bEdu3E3upM":
        Script89();
        break;
      case "6mWFPmaRqaH":
        Script90();
        break;
      case "6GACEGaAStg":
        Script91();
        break;
      case "6i0zquEr5iG":
        Script92();
        break;
      case "5wl2pvnGqMK":
        Script93();
        break;
      case "6r2He1pM3qp":
        Script94();
        break;
      case "6IwcyOr5KdW":
        Script95();
        break;
      case "5itCKBSOFs5":
        Script96();
        break;
      case "6VnPcNJ4FHf":
        Script97();
        break;
      case "6WgvPnGzuvP":
        Script98();
        break;
      case "65CaNG3ZrCu":
        Script99();
        break;
      case "5WZ15z2129y":
        Script100();
        break;
      case "6VAwxtNeFq8":
        Script101();
        break;
      case "6SyQO2rC1gs":
        Script102();
        break;
      case "6HhZNr313XR":
        Script103();
        break;
      case "5wg3UeWCxz3":
        Script104();
        break;
      case "6TLGF4FGa3c":
        Script105();
        break;
      case "6W8AYTwe1Eh":
        Script106();
        break;
      case "5ZqOYPEln5a":
        Script107();
        break;
      case "64FcPSNiD9f":
        Script108();
        break;
      case "6i0AMtMtpKy":
        Script109();
        break;
      case "633piR7Lmqt":
        Script110();
        break;
      case "6PIxjPVMUR5":
        Script111();
        break;
      case "65UPueo21vN":
        Script112();
        break;
      case "6kf9jiRIYi6":
        Script113();
        break;
      case "61A9LUmXcFk":
        Script114();
        break;
      case "6eaGKfcA3EF":
        Script115();
        break;
      case "6iSmc75EQHf":
        Script116();
        break;
      case "5X3bU6T6nfg":
        Script117();
        break;
      case "5gAUO3B00J7":
        Script118();
        break;
      case "6VC672g6hqt":
        Script119();
        break;
      case "6YbnIiI6LXi":
        Script120();
        break;
      case "5zqa2BlE2jR":
        Script121();
        break;
      case "6jCjpqzNfq6":
        Script122();
        break;
      case "6DMGMaE62ne":
        Script123();
        break;
      case "5gf3eSYGD2G":
        Script124();
        break;
      case "6MLaaXNtLue":
        Script125();
        break;
      case "5xJD4Rt4bYJ":
        Script126();
        break;
      case "5smlB7QBGZ3":
        Script127();
        break;
      case "6TOygbC6jns":
        Script128();
        break;
      case "5llLdyQA63A":
        Script129();
        break;
      case "5xanyZln4tJ":
        Script130();
        break;
      case "6lrGRkhZfKe":
        Script131();
        break;
      case "6Sd4uBnI9HI":
        Script132();
        break;
      case "5egb70Nfkt7":
        Script133();
        break;
      case "5aG6Cx64XQU":
        Script134();
        break;
      case "5c74c4f1gKy":
        Script135();
        break;
      case "6fRM3pGY704":
        Script136();
        break;
      case "6hggWUDmgFq":
        Script137();
        break;
      case "5bsOpKiS1ZT":
        Script138();
        break;
      case "5gIvcAdi0NH":
        Script139();
        break;
      case "60S2tUx3tLb":
        Script140();
        break;
      case "6cXdlaewvS5":
        Script141();
        break;
      case "6P5FDIcQx1X":
        Script142();
        break;
      case "5hQ1UPkWELS":
        Script143();
        break;
      case "5ccpXQyYws3":
        Script144();
        break;
      case "5zbo9aDPNDq":
        Script145();
        break;
      case "6O2gwhVxFhN":
        Script146();
        break;
      case "6Nfx9WOZ4Re":
        Script147();
        break;
      case "6PKJX5kobGe":
        Script148();
        break;
      case "5g5CshOxIzw":
        Script149();
        break;
      case "5qHSvDx6GQv":
        Script150();
        break;
      case "5p7gOikc5bG":
        Script151();
        break;
      case "5h3KEq8KCnA":
        Script152();
        break;
      case "5wiW1nLH49f":
        Script153();
        break;
      case "5rxOcLyy3zr":
        Script154();
        break;
      case "5kuN45oj25T":
        Script155();
        break;
      case "6iXtmzM4jTy":
        Script156();
        break;
      case "5neoDynw4WE":
        Script157();
        break;
      case "5uoGj0znmLc":
        Script158();
        break;
      case "6VDOZKiPIqk":
        Script159();
        break;
      case "6eitWuiZrRO":
        Script160();
        break;
      case "5Uku7T9tbqx":
        Script161();
        break;
      case "66aZSQ9RaO9":
        Script162();
        break;
      case "6q48vKasgb6":
        Script163();
        break;
      case "6fLDWRfhG7B":
        Script164();
        break;
      case "5w8KlOvE4C4":
        Script165();
        break;
      case "6lstxeuzSYf":
        Script166();
        break;
      case "6Z7UtsrykRe":
        Script167();
        break;
      case "6KRUzWZrADq":
        Script168();
        break;
      case "6KHjrBDpPrF":
        Script169();
        break;
      case "6IyXusnQrna":
        Script170();
        break;
      case "6X83WdmGiEL":
        Script171();
        break;
      case "6d8OAL4vsh6":
        Script172();
        break;
      case "6nWPWxB7AZk":
        Script173();
        break;
      case "5dDV36tWA9p":
        Script174();
        break;
      case "5xKOVlIc4wq":
        Script175();
        break;
      case "63NpLvFANkH":
        Script176();
        break;
      case "6g1APiJ6hua":
        Script177();
        break;
      case "5l9zAftTjOQ":
        Script178();
        break;
      case "5c1vxDkgcBq":
        Script179();
        break;
      case "5koEK3bmhLy":
        Script180();
        break;
      case "60tC5VfOOU3":
        Script181();
        break;
      case "6kbHISlZ0dQ":
        Script182();
        break;
      case "6p865VxXzIL":
        Script183();
        break;
      case "6cCAuPzcRIq":
        Script184();
        break;
      case "6Nk590GgI8k":
        Script185();
        break;
      case "6r6pcWfpOEd":
        Script186();
        break;
      case "6kUFlntOGjF":
        Script187();
        break;
      case "6lqgvZWet1m":
        Script188();
        break;
      case "6ndZHLU5XIi":
        Script189();
        break;
      case "6qUm1RFpdN1":
        Script190();
        break;
      case "6j4MRswNZj5":
        Script191();
        break;
      case "6TcXgXb1FEO":
        Script192();
        break;
      case "6Wu37xTao30":
        Script193();
        break;
      case "6r8x37Svexy":
        Script194();
        break;
      case "5fhZV5Z0zJn":
        Script195();
        break;
      case "5WSjKU9NY6U":
        Script196();
        break;
      case "6GTYwkKeEM6":
        Script197();
        break;
      case "5wp7ZsZEEXp":
        Script198();
        break;
      case "6MtFwXxgf7k":
        Script199();
        break;
      case "5lVdlGauYyv":
        Script200();
        break;
      case "6QSgX9OCIC5":
        Script201();
        break;
      case "6O9uuwLr8Ls":
        Script202();
        break;
      case "6DgjdIXXvmZ":
        Script203();
        break;
      case "5ZoSBFKRiqG":
        Script204();
        break;
      case "6icQltwRTRs":
        Script205();
        break;
      case "5VrnJy9yjS2":
        Script206();
        break;
      case "5uHnWpguNpD":
        Script207();
        break;
      case "6OACLDy9D0I":
        Script208();
        break;
      case "5gwoA3nL0lM":
        Script209();
        break;
      case "6pvFTbxBg9c":
        Script210();
        break;
      case "5ptkQ2m6CkJ":
        Script211();
        break;
      case "5Yj6SZwM4zl":
        Script212();
        break;
      case "67hwy9G86tg":
        Script213();
        break;
      case "6rbfbdzJfa7":
        Script214();
        break;
      case "6fghk7zW7Mc":
        Script215();
        break;
      case "62Gfx3YGtvn":
        Script216();
        break;
      case "6ocoj5HPRcC":
        Script217();
        break;
      case "5fopnOZ5Hib":
        Script218();
        break;
      case "69elDF29bgu":
        Script219();
        break;
      case "6bk0Lg6JVUI":
        Script220();
        break;
      case "61pMFIqcMyF":
        Script221();
        break;
      case "60LT9FwQ6gO":
        Script222();
        break;
      case "5m0fZdBPSt0":
        Script223();
        break;
      case "6hXLPmnFJYZ":
        Script224();
        break;
      case "5vAQJKoxWQ4":
        Script225();
        break;
      case "5whFZT6rQ4w":
        Script226();
        break;
      case "6TuYxYrv0ce":
        Script227();
        break;
      case "5bb2nf66Hsm":
        Script228();
        break;
      case "6l8GLivHwml":
        Script229();
        break;
      case "6HQHgmR1lUo":
        Script230();
        break;
      case "66RtEEo9Mzy":
        Script231();
        break;
      case "5zgKOQFtpkR":
        Script232();
        break;
      case "5uhLwZlSnqh":
        Script233();
        break;
      case "6MAkhT1r6OH":
        Script234();
        break;
      case "68irHAtu9Kr":
        Script235();
        break;
      case "5YuMk8qZxIp":
        Script236();
        break;
      case "6UYUPL6L0TT":
        Script237();
        break;
      case "6oPgB71JCbY":
        Script238();
        break;
      case "6Qo2sTWGWf7":
        Script239();
        break;
      case "6mdRNufH7Hi":
        Script240();
        break;
      case "6dtc2T8HuYJ":
        Script241();
        break;
      case "5ZLwNrBFhdG":
        Script242();
        break;
      case "5lT2xZ9VAdK":
        Script243();
        break;
      case "5gClo0rCwPV":
        Script244();
        break;
      case "6Tkro6FZOOb":
        Script245();
        break;
      case "6alvYpwo1vS":
        Script246();
        break;
      case "6fotJDFmODL":
        Script247();
        break;
      case "6eLh3zYIoKH":
        Script248();
        break;
      case "6iZamsCQ4HJ":
        Script249();
        break;
      case "6ChiVK5C3So":
        Script250();
        break;
      case "69TaU8BHtB0":
        Script251();
        break;
      case "6DyMuwiAhIe":
        Script252();
        break;
      case "6q8oDDccuXz":
        Script253();
        break;
      case "6WM6NGl4MVH":
        Script254();
        break;
      case "6TtIctCCWSC":
        Script255();
        break;
      case "6Zc24QdIBiZ":
        Script256();
        break;
      case "6U3PpttvVZC":
        Script257();
        break;
      case "60PNu21AWgs":
        Script258();
        break;
      case "5VmXOD1PNoZ":
        Script259();
        break;
      case "62vikCpduM1":
        Script260();
        break;
      case "5bow9sDz7au":
        Script261();
        break;
      case "5ipsqUd5ksA":
        Script262();
        break;
      case "6pYzNRjYRyk":
        Script263();
        break;
      case "67SzsvxPlGT":
        Script264();
        break;
      case "6ixWiSfAPOg":
        Script265();
        break;
      case "64UHrSqs65H":
        Script266();
        break;
      case "5tSzmy8HN74":
        Script267();
        break;
      case "6cCnF9lxTAS":
        Script268();
        break;
      case "6DGlm0yXBuP":
        Script269();
        break;
      case "6p8j5zG5se5":
        Script270();
        break;
      case "5xvGI8X2XE9":
        Script271();
        break;
      case "6paMklvHGbH":
        Script272();
        break;
      case "6ky2CpGv2j4":
        Script273();
        break;
      case "6Ecktg7V2aG":
        Script274();
        break;
      case "6R72q6YDsmP":
        Script275();
        break;
      case "6DwKt3Z1wmM":
        Script276();
        break;
      case "5WAk2YG8jxp":
        Script277();
        break;
      case "62GVrD3iMoM":
        Script278();
        break;
      case "5mRcbwBFn1d":
        Script279();
        break;
      case "6YMfYrMj9pw":
        Script280();
        break;
      case "6gB89UlXICH":
        Script281();
        break;
      case "6IaF0927zbP":
        Script282();
        break;
      case "6JJ7hEAOMf0":
        Script283();
        break;
      case "6DgiGKSn3h5":
        Script284();
        break;
      case "6Vk3MOuiSsn":
        Script285();
        break;
      case "5vgAEhk5ZsK":
        Script286();
        break;
      case "6NHF9e9lBjG":
        Script287();
        break;
      case "6FtOOYJhbjS":
        Script288();
        break;
      case "5zQot2i0P5A":
        Script289();
        break;
      case "6PVlPXuQyVc":
        Script290();
        break;
      case "6eSFvmY3Uph":
        Script291();
        break;
      case "6VU3gEBBEkD":
        Script292();
        break;
      case "5el0FUrCpQV":
        Script293();
        break;
      case "6ApFgkScYaB":
        Script294();
        break;
      case "68dMnFO3PSm":
        Script295();
        break;
      case "6ZZKp3HfWV1":
        Script296();
        break;
      case "6jLUsTL6FSd":
        Script297();
        break;
      case "5eCv0LSILUe":
        Script298();
        break;
      case "5caTFtpb4HE":
        Script299();
        break;
      case "5ikc6P0CKjT":
        Script300();
        break;
      case "6hpY4cE5XV2":
        Script301();
        break;
      case "6IWYKRRPJnV":
        Script302();
        break;
      case "6HZ3pFUsjqc":
        Script303();
        break;
      case "5YkPwzYXyRN":
        Script304();
        break;
      case "5bOnuE5lMiA":
        Script305();
        break;
      case "6SJAdY800OF":
        Script306();
        break;
      case "6CRPzl0dMCd":
        Script307();
        break;
      case "6WA3kcWJg70":
        Script308();
        break;
      case "5xBrO26pMXS":
        Script309();
        break;
      case "6Qnn06N5PXE":
        Script310();
        break;
      case "6KCTgZRiz3S":
        Script311();
        break;
      case "5YYZetj0tIA":
        Script312();
        break;
      case "5n0ZMSpr48V":
        Script313();
        break;
      case "5cf33nqa7RN":
        Script314();
        break;
      case "6IErIVx4EkL":
        Script315();
        break;
      case "6phz1BJ92hu":
        Script316();
        break;
      case "62Poe1By9EQ":
        Script317();
        break;
      case "6ONLFmySUWP":
        Script318();
        break;
      case "5sZaQ0eIf5k":
        Script319();
        break;
      case "5lnpQEhLs7p":
        Script320();
        break;
      case "6kFt3QiGp8Z":
        Script321();
        break;
      case "6N443WNckDi":
        Script322();
        break;
      case "66EQsISvlTv":
        Script323();
        break;
      case "61tkuuIk5ui":
        Script324();
        break;
      case "6WP86C46MDd":
        Script325();
        break;
      case "6NqTvKEZ3jS":
        Script326();
        break;
      case "6HQe5ALCreR":
        Script327();
        break;
      case "6Dzy4Qhr6yh":
        Script328();
        break;
      case "6ETvAhQMEnw":
        Script329();
        break;
      case "5hRYOtTxfMw":
        Script330();
        break;
      case "5sLoSycFSnf":
        Script331();
        break;
      case "6BB9BioEhGw":
        Script332();
        break;
      case "6PdQgL5UlsL":
        Script333();
        break;
      case "6q3vSCnhPA7":
        Script334();
        break;
      case "6gjKNLp7uhk":
        Script335();
        break;
      case "6KIewnwqI7h":
        Script336();
        break;
      case "6HFQIG8BTSF":
        Script337();
        break;
      case "5i0xnBvS4bX":
        Script338();
        break;
      case "6QpTrrCfjCT":
        Script339();
        break;
      case "6WbNw4awOHV":
        Script340();
        break;
      case "5zJYWcHJtQg":
        Script341();
        break;
      case "5eMIjTGLNhy":
        Script342();
        break;
      case "5gjiYSE56aT":
        Script343();
        break;
      case "6mCfjLQCQDZ":
        Script344();
        break;
      case "5ta9kq1K9kj":
        Script345();
        break;
      case "608KvCa5VJn":
        Script346();
        break;
      case "5W9js1aljw0":
        Script347();
        break;
      case "6E7WAfceeUy":
        Script348();
        break;
      case "5znLDslUziA":
        Script349();
        break;
      case "6anWzMJuuYN":
        Script350();
        break;
      case "6jG6SDhG8w6":
        Script351();
        break;
      case "6eYG9A6v3uH":
        Script352();
        break;
      case "6L3ptAAgHhq":
        Script353();
        break;
      case "6hknoCUCSt8":
        Script354();
        break;
      case "5rr0JlCrYrG":
        Script355();
        break;
      case "5qbtGgA0ufZ":
        Script356();
        break;
      case "6fEvjBwRYot":
        Script357();
        break;
      case "5pWyPCnu3dI":
        Script358();
        break;
      case "6hvQgdacL4W":
        Script359();
        break;
      case "5yw3SSF0Nwx":
        Script360();
        break;
      case "6AE7VFucTk0":
        Script361();
        break;
      case "6DlRvdM0fex":
        Script362();
        break;
      case "6XXeFPLHWJx":
        Script363();
        break;
      case "6BKdYIEQ3Dn":
        Script364();
        break;
      case "6CmH2fvrBlL":
        Script365();
        break;
      case "6RFfpEs0yse":
        Script366();
        break;
      case "5rRB8JvVoKd":
        Script367();
        break;
      case "6IdBmSMDbj5":
        Script368();
        break;
      case "5bCzjDOf09O":
        Script369();
        break;
      case "60NgJ8eXd3O":
        Script370();
        break;
      case "5scyxDqTpou":
        Script371();
        break;
      case "6NqwXuZCPEe":
        Script372();
        break;
      case "6CuHwRpbeQV":
        Script373();
        break;
      case "6b4sCSKKpR7":
        Script374();
        break;
  }
}

function Script1()
{
  var Utama =document.getElementById('bgSongku');
Utama.src="musikku.mp3";
Utama.load();
Utama.play();
Utama.volume=0.1;
}

function Script2()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script3()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script4()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script5()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script6()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script7()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script8()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script9()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script10()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script11()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script12()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script13()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script14()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script15()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script16()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script17()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script18()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script19()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script20()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script21()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script22()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script23()
{
  var QuizMusic = document.getElementById('quizsong');
if (QuizMusic) {
    QuizMusic.currentTime = 0;  
    QuizMusic.play();         
}

}

function Script24()
{
  var QuizMusic= document.getElementById('quizsong');
if (QuizMusic) {
   QuizMusic.src = "quizmusic.mp3";   
   QuizMusic.load();                 
   QuizMusic.play();                 
   QuizMusic.volume = 0.1;          
}

}

function Script25()
{
  var PreviousMusic = document.getElementById("bgSongku");

var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");

if (PreviousMusic) {
    
   PreviousMusic.pause();
    
   PreviousMusic.currentTime = 0; // 

}
if (LearningMusic) {
   LearningMusic.pause();
   LearningMusic.currentTime = 0;
}
if (QuizMusic) {
   QuizMusic.play();
}
}

function Script26()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script27()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script28()
{
  var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");
var Utama = document.getElementById('bgSongku');


if (LearningMusic) {
    
   LearningMusic.pause();
    
   LearningMusic.currentTime = 0;

}
if (QuizMusic) {
   QuizMusic.pause();
   QuizMusic.currentTime = 0;
}
if (Utama) {
   Utama.play();
}
}

function Script29()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script30()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
   Utama.pause();
}

}

function Script31()
{
  var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");
var Utama = document.getElementById('bgSongku');


if (LearningMusic) {
    
   LearningMusic.pause();
    
   LearningMusic.currentTime = 0;

}
if (QuizMusic) {
   QuizMusic.pause();
   QuizMusic.currentTime = 0;
}
if (Utama) {
   Utama.play();
}
}

function Script32()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script33()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
   Utama.pause();
}

}

function Script34()
{
  var QuizMusic = document.getElementById('quizsong');
if (QuizMusic) {
    QuizMusic.currentTime = 0;  
    QuizMusic.play();         
}

}

function Script35()
{
  var QuizMusic= document.getElementById('quizsong');
if (QuizMusic) {
   QuizMusic.src = "quizmusic.mp3";   
   QuizMusic.load();                 
   QuizMusic.play();                 
   QuizMusic.volume = 0.1;          
}

}

function Script36()
{
  var PreviousMusic = document.getElementById("bgSongku");

var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");

if (PreviousMusic) {
    
   PreviousMusic.pause();
    
   PreviousMusic.currentTime = 0; // 

}
if (LearningMusic) {
   LearningMusic.pause();
   LearningMusic.currentTime = 0;
}
if (QuizMusic) {
   QuizMusic.play();
}
}

function Script37()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script38()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script39()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script40()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script41()
{
  var QuizMusic = document.getElementById('quizsong');
if (QuizMusic) {
    QuizMusic.currentTime = 0;  
    QuizMusic.play();         
}

}

function Script42()
{
  var QuizMusic= document.getElementById('quizsong');
if (QuizMusic) {
   QuizMusic.src = "quizmusic.mp3";   
   QuizMusic.load();                 
   QuizMusic.play();                 
   QuizMusic.volume = 0.1;          
}

}

function Script43()
{
  var PreviousMusic = document.getElementById("bgSongku");

var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");

if (PreviousMusic) {
    
   PreviousMusic.pause();
    
   PreviousMusic.currentTime = 0; // 

}
if (LearningMusic) {
   LearningMusic.pause();
   LearningMusic.currentTime = 0;
}
if (QuizMusic) {
   QuizMusic.play();
}
}

function Script44()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script45()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script46()
{
  var QuizMusic = document.getElementById('quizsong');
if (QuizMusic) {
    QuizMusic.currentTime = 0;  
    QuizMusic.play();         
}

}

function Script47()
{
  var QuizMusic= document.getElementById('quizsong');
if (QuizMusic) {
   QuizMusic.src = "quizmusic.mp3";   
   QuizMusic.load();                 
   QuizMusic.play();                 
   QuizMusic.volume = 0.1;          
}

}

function Script48()
{
  var PreviousMusic = document.getElementById("bgSongku");

var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");

if (PreviousMusic) {
    
   PreviousMusic.pause();
    
   PreviousMusic.currentTime = 0; // 

}
if (LearningMusic) {
   LearningMusic.pause();
   LearningMusic.currentTime = 0;
}
if (QuizMusic) {
   QuizMusic.play();
}
}

function Script49()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script50()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script51()
{
  var QuizMusic = document.getElementById('quizsong');
if (QuizMusic) {
    QuizMusic.currentTime = 0;  
    QuizMusic.play();         
}

}

function Script52()
{
  var QuizMusic= document.getElementById('quizsong');
if (QuizMusic) {
   QuizMusic.src = "quizmusic.mp3";   
   QuizMusic.load();                 
   QuizMusic.play();                 
   QuizMusic.volume = 0.1;          
}

}

function Script53()
{
  var PreviousMusic = document.getElementById("bgSongku");

var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");

if (PreviousMusic) {
    
   PreviousMusic.pause();
    
   PreviousMusic.currentTime = 0; // 

}
if (LearningMusic) {
   LearningMusic.pause();
   LearningMusic.currentTime = 0;
}
if (QuizMusic) {
   QuizMusic.play();
}
}

function Script54()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script55()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script56()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script57()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script58()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script59()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script60()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script61()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script62()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script63()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script64()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script65()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script66()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script67()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script68()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script69()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script70()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script71()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script72()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script73()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script74()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script75()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script76()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script77()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script78()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script79()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script80()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script81()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script82()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script83()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script84()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script85()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script86()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script87()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script88()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script89()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script90()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script91()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script92()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script93()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script94()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script95()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script96()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script97()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script98()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script99()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script100()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script101()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script102()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script103()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script104()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script105()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script106()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script107()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script108()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script109()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script110()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script111()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script112()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script113()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script114()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script115()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script116()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script117()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script118()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script119()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script120()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script121()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script122()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script123()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script124()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script125()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script126()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script127()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script128()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script129()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script130()
{
  var LearningMusic = document.getElementById('learningsong');
LearningMusic.src="learningmusic.mp3";
LearningMusic.load();
LearningMusic.play();
LearningMusic.volume=0.1;
}

function Script131()
{
  var Utama = document.getElementById("bgSongku");

var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");

if (Utama) {
    
   Utama.pause();
    
   Utama.currentTime = 0;

}
if (QuizMusic) {
   QuizMusic.pause();
   QuizMusic.currentTime = 0;
}
if (LearningMusic) {
   LearningMusic.play();
}
}

function Script132()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script133()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script134()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script135()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script136()
{
  var LearningMusic = document.getElementById('learningsong');
LearningMusic.src="learningmusic.mp3";
LearningMusic.load();
LearningMusic.play();
LearningMusic.volume=0.1;
}

function Script137()
{
  var Utama = document.getElementById("bgSongku");

var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");

if (Utama) {
    
   Utama.pause();
    
   Utama.currentTime = 0;

}
if (QuizMusic) {
   QuizMusic.pause();
   QuizMusic.currentTime = 0;
}
if (LearningMusic) {
   LearningMusic.play();
}
}

function Script138()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script139()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script140()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script141()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script142()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script143()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script144()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script145()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script146()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script147()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script148()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script149()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script150()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script151()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script152()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script153()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script154()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script155()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script156()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script157()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script158()
{
  var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");
var Utama = document.getElementById('bgSongku');


if (LearningMusic) {
    
   LearningMusic.pause();
    
   LearningMusic.currentTime = 0;

}
if (QuizMusic) {
   QuizMusic.pause();
   QuizMusic.currentTime = 0;
}
if (Utama) {
   Utama.play();
}
}

function Script159()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script160()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
   Utama.pause();
}

}

function Script161()
{
  var LearningMusic = document.getElementById('learningsong');
LearningMusic.src="learningmusic.mp3";
LearningMusic.load();
LearningMusic.play();
LearningMusic.volume=0.1;
}

function Script162()
{
  var Utama = document.getElementById("bgSongku");

var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");

if (Utama) {
    
   Utama.pause();
    
   Utama.currentTime = 0;

}
if (QuizMusic) {
   QuizMusic.pause();
   QuizMusic.currentTime = 0;
}
if (LearningMusic) {
   LearningMusic.play();
}
}

function Script163()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script164()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script165()
{
  var LearningMusic = document.getElementById('learningsong');
LearningMusic.src="learningmusic.mp3";
LearningMusic.load();
LearningMusic.play();
LearningMusic.volume=0.1;
}

function Script166()
{
  var Utama = document.getElementById("bgSongku");

var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");

if (Utama) {
    
   Utama.pause();
    
   Utama.currentTime = 0;

}
if (QuizMusic) {
   QuizMusic.pause();
   QuizMusic.currentTime = 0;
}
if (LearningMusic) {
   LearningMusic.play();
}
}

function Script167()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script168()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script169()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script170()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script171()
{
  var LearningMusic = document.getElementById('learningsong');
LearningMusic.src="learningmusic.mp3";
LearningMusic.load();
LearningMusic.play();
LearningMusic.volume=0.1;
}

function Script172()
{
  var Utama = document.getElementById("bgSongku");

var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");

if (Utama) {
    
   Utama.pause();
    
   Utama.currentTime = 0;

}
if (QuizMusic) {
   QuizMusic.pause();
   QuizMusic.currentTime = 0;
}
if (LearningMusic) {
   LearningMusic.play();
}
}

function Script173()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script174()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script175()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script176()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script177()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script178()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script179()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script180()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script181()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script182()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script183()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script184()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script185()
{
  var LearningMusic = document.getElementById('learningsong');
LearningMusic.src="learningmusic.mp3";
LearningMusic.load();
LearningMusic.play();
LearningMusic.volume=0.1;
}

function Script186()
{
  var Utama = document.getElementById("bgSongku");

var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");

if (Utama) {
    
   Utama.pause();
    
   Utama.currentTime = 0;

}
if (QuizMusic) {
   QuizMusic.pause();
   QuizMusic.currentTime = 0;
}
if (LearningMusic) {
   LearningMusic.play();
}
}

function Script187()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script188()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script189()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script190()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script191()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script192()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script193()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script194()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script195()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script196()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script197()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script198()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script199()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script200()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script201()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script202()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script203()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script204()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script205()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script206()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script207()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script208()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script209()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script210()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script211()
{
  var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");
var Utama = document.getElementById('bgSongku');


if (LearningMusic) {
    
   LearningMusic.pause();
    
   LearningMusic.currentTime = 0; 

}
if (QuizMusic) {
   QuizMusic.pause();
   QuizMusic.currentTime = 0;
}
if (Utama) {
   Utama.play(); 
}
}

function Script212()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script213()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script214()
{
  var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");
var Utama = document.getElementById('bgSongku');


if (LearningMusic) {
    
   LearningMusic.pause();
    
   LearningMusic.currentTime = 0; 

}
if (QuizMusic) {
   QuizMusic.pause();
   QuizMusic.currentTime = 0;
}
if (Utama) {
   Utama.play(); 
}
}

function Script215()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script216()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.pause();
}

}

function Script217()
{
  var QuizMusic = document.getElementById('quizsong');
if (QuizMusic) {
    QuizMusic.currentTime = 0;  
    QuizMusic.play();         
}

}

function Script218()
{
  var QuizMusic= document.getElementById('quizsong');
if (QuizMusic) {
   QuizMusic.src = "quizmusic.mp3";   
   QuizMusic.load();                 
   QuizMusic.play();                 
   QuizMusic.volume = 0.1;          
}

}

function Script219()
{
  var PreviousMusic = document.getElementById("bgSongku");

var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");

if (PreviousMusic) {
    
   PreviousMusic.pause();
    
   PreviousMusic.currentTime = 0; // 

}
if (LearningMusic) {
   LearningMusic.pause();
   LearningMusic.currentTime = 0;
}
if (QuizMusic) {
   QuizMusic.play();
}
}

function Script220()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script221()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script222()
{
  var QuizMusic = document.getElementById('quizsong');
if (QuizMusic) {
    QuizMusic.currentTime = 0;  
    QuizMusic.play();         
}

}

function Script223()
{
  var QuizMusic= document.getElementById('quizsong');
if (QuizMusic) {
   QuizMusic.src = "quizmusic.mp3";   
   QuizMusic.load();                 
   QuizMusic.play();                 
   QuizMusic.volume = 0.1;          
}

}

function Script224()
{
  var PreviousMusic = document.getElementById("bgSongku");

var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");

if (PreviousMusic) {
    
   PreviousMusic.pause();
    
   PreviousMusic.currentTime = 0; // 

}
if (LearningMusic) {
   LearningMusic.pause();
   LearningMusic.currentTime = 0;
}
if (QuizMusic) {
   QuizMusic.play();
}
}

function Script225()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script226()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script227()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script228()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script229()
{
  var QuizMusic = document.getElementById('quizsong');
if (QuizMusic) {
    QuizMusic.currentTime = 0;  
    QuizMusic.play();         
}

}

function Script230()
{
  var QuizMusic= document.getElementById('quizsong');
if (QuizMusic) {
   QuizMusic.src = "quizmusic.mp3";   
   QuizMusic.load();                 
   QuizMusic.play();                 
   QuizMusic.volume = 0.1;          
}

}

function Script231()
{
  var PreviousMusic = document.getElementById("bgSongku");

var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");

if (PreviousMusic) {
    
   PreviousMusic.pause();
    
   PreviousMusic.currentTime = 0; // 

}
if (LearningMusic) {
   LearningMusic.pause();
   LearningMusic.currentTime = 0;
}
if (QuizMusic) {
   QuizMusic.play();
}
}

function Script232()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script233()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script234()
{
  var QuizMusic = document.getElementById('quizsong');
if (QuizMusic) {
    QuizMusic.currentTime = 0;  
    QuizMusic.play();         
}

}

function Script235()
{
  var QuizMusic= document.getElementById('quizsong');
if (QuizMusic) {
   QuizMusic.src = "quizmusic.mp3";   
   QuizMusic.load();                 
   QuizMusic.play();                 
   QuizMusic.volume = 0.1;          
}

}

function Script236()
{
  var PreviousMusic = document.getElementById("bgSongku");

var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");

if (PreviousMusic) {
    
   PreviousMusic.pause();
    
   PreviousMusic.currentTime = 0; // 

}
if (LearningMusic) {
   LearningMusic.pause();
   LearningMusic.currentTime = 0;
}
if (QuizMusic) {
   QuizMusic.play();
}
}

function Script237()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script238()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script239()
{
  var QuizMusic = document.getElementById('quizsong');
if (QuizMusic) {
    QuizMusic.currentTime = 0;  
    QuizMusic.play();         
}

}

function Script240()
{
  var QuizMusic= document.getElementById('quizsong');
if (QuizMusic) {
   QuizMusic.src = "quizmusic.mp3";   
   QuizMusic.load();                 
   QuizMusic.play();                 
   QuizMusic.volume = 0.1;          
}

}

function Script241()
{
  var PreviousMusic = document.getElementById("bgSongku");

var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");

if (PreviousMusic) {
    
   PreviousMusic.pause();
    
   PreviousMusic.currentTime = 0; // 

}
if (LearningMusic) {
   LearningMusic.pause();
   LearningMusic.currentTime = 0;
}
if (QuizMusic) {
   QuizMusic.play();
}
}

function Script242()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script243()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script244()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script245()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script246()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script247()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script248()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script249()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script250()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script251()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script252()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script253()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script254()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script255()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script256()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script257()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script258()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script259()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script260()
{
  var QuizMusic = document.getElementById('quizsong');
if (QuizMusic) {
    QuizMusic.currentTime = 0;  
    QuizMusic.play();         
}

}

function Script261()
{
  var QuizMusic= document.getElementById('quizsong');
if (QuizMusic) {
   QuizMusic.src = "quizmusic.mp3";   
   QuizMusic.load();                 
   QuizMusic.play();                 
   QuizMusic.volume = 0.1;          
}

}

function Script262()
{
  var PreviousMusic = document.getElementById("bgSongku");

var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");

if (PreviousMusic) {
    
   PreviousMusic.pause();
    
   PreviousMusic.currentTime = 0; // 

}
if (LearningMusic) {
   LearningMusic.pause();
   LearningMusic.currentTime = 0;
}
if (QuizMusic) {
   QuizMusic.play();
}
}

function Script263()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script264()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script265()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script266()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script267()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script268()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script269()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script270()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script271()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script272()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script273()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script274()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script275()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script276()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script277()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script278()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script279()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script280()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script281()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script282()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script283()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script284()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script285()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script286()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script287()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script288()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script289()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script290()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script291()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script292()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script293()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script294()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script295()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script296()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script297()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script298()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script299()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script300()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script301()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script302()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script303()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script304()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script305()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script306()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script307()
{
  var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");
var Utama = document.getElementById('bgSongku');


if (LearningMusic) {
    
   LearningMusic.pause();
    
   LearningMusic.currentTime = 0;

}
if (QuizMusic) {
   QuizMusic.pause();
   QuizMusic.currentTime = 0;
}
if (Utama) {
   Utama.play();
}
}

function Script308()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script309()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
   Utama.pause();
}

}

function Script310()
{
  var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");
var Utama = document.getElementById('bgSongku');


if (LearningMusic) {
    
   LearningMusic.pause();
    
   LearningMusic.currentTime = 0;

}
if (QuizMusic) {
   QuizMusic.pause();
   QuizMusic.currentTime = 0;
}
if (Utama) {
   Utama.play();
}
}

function Script311()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script312()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
   Utama.pause();
}

}

function Script313()
{
  var QuizMusic = document.getElementById('quizsong');
if (QuizMusic) {
    QuizMusic.currentTime = 0;  
    QuizMusic.play();         
}

}

function Script314()
{
  var QuizMusic= document.getElementById('quizsong');
if (QuizMusic) {
   QuizMusic.src = "quizmusic.mp3";   
   QuizMusic.load();                 
   QuizMusic.play();                 
   QuizMusic.volume = 0.1;          
}

}

function Script315()
{
  var PreviousMusic = document.getElementById("bgSongku");

var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");

if (PreviousMusic) {
    
   PreviousMusic.pause();
    
   PreviousMusic.currentTime = 0; // 

}
if (LearningMusic) {
   LearningMusic.pause();
   LearningMusic.currentTime = 0;
}
if (QuizMusic) {
   QuizMusic.play();
}
}

function Script316()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script317()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script318()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script319()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script320()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script321()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script322()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script323()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script324()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script325()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script326()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script327()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script328()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script329()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script330()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script331()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script332()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script333()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script334()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.play();
}




}

function Script335()
{
  var player = GetPlayer();
var audioID ="learningsong";
var LearningMusic = document.getElementById('learningsong');

if (LearningMusic) {
   LearningMusic.pause();
}
}

function Script336()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script337()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script338()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script339()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script340()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script341()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script342()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script343()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script344()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script345()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script346()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script347()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script348()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script349()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script350()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script351()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script352()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script353()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script354()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script355()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script356()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script357()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script358()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script359()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script360()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script361()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script362()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script363()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script364()
{
  var LearningMusic = document.getElementById("learningsong");
var QuizMusic = document.getElementById("quizsong");
var Utama = document.getElementById('bgSongku');


if (LearningMusic) {
    
   LearningMusic.pause();
    
   LearningMusic.currentTime = 0;

}
if (QuizMusic) {
   QuizMusic.pause();
   QuizMusic.currentTime = 0;
}
if (Utama) {
   Utama.play();
}
}

function Script365()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
    Utama.play();
}

}

function Script366()
{
  var player = GetPlayer();
var Utama = document.getElementById("bgSongku");
if (Utama) {
   Utama.pause();
}

}

function Script367()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script368()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script369()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script370()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script371()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script372()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

function Script373()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.play();
}




}

function Script374()
{
  var player = GetPlayer();
var audioID ="quizsong";
var QuizMusic = document.getElementById('quizsong');

if (QuizMusic) {
   QuizMusic.pause();
}
}

